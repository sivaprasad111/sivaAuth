# SIVA Authentication
 An authentication system built using **J**WTs, **A**ngular, **M**ySQL, **E**xpress and **S**equelize in the [Creating a Role-Based User Authentication System Using Angular, Express and MySQL]

### Installation
 In order to install the dependencies run:
```
npm install
```

### Starting the Server
In order to start the server run:
```
node app/server.js
```